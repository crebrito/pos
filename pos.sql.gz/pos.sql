-- Adminer 4.8.0 MySQL 5.5.5-10.3.27-MariaDB-0+deb10u1 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP DATABASE IF EXISTS `pos`;
CREATE DATABASE `pos` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `pos`;

DROP TABLE IF EXISTS `categorias`;
CREATE TABLE `categorias` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `activo` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

TRUNCATE `categorias`;
INSERT INTO `categorias` (`id`, `nombre`, `activo`, `created_at`, `updated_at`) VALUES
(1,	'Tecnologías',	1,	'2021-03-07 19:29:49',	'2021-03-07 17:29:49'),
(2,	'Papelería',	1,	'2021-03-10 16:46:50',	'2021-03-10 14:46:50');

DROP TABLE IF EXISTS `clientes`;
CREATE TABLE `clientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `direccion` varchar(150) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `correo` varchar(50) DEFAULT NULL,
  `activo` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

TRUNCATE `clientes`;
INSERT INTO `clientes` (`id`, `nombre`, `direccion`, `telefono`, `correo`, `activo`, `created_at`, `updated_at`) VALUES
(1,	'Carlos',	'alla',	'123456',	'aa@aa.com',	1,	'2021-03-11 01:05:01',	'2021-03-10 23:05:01');

DROP TABLE IF EXISTS `configuracion`;
CREATE TABLE `configuracion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `valor` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

TRUNCATE `configuracion`;
INSERT INTO `configuracion` (`id`, `nombre`, `valor`) VALUES
(1,	'tienda_nombre',	'Tienda CDP'),
(2,	'tienda_rif',	'J-12345678-3'),
(3,	'tienda_correo',	'aa@aa.com'),
(4,	'tienda_telefono',	'04143404376'),
(5,	'tienda_direccion',	'Av. Mañongo 3'),
(6,	'ticket_leyenda',	'Gracias por su paciencia');

DROP TABLE IF EXISTS `productos`;
CREATE TABLE `productos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(20) NOT NULL,
  `nombre` varchar(200) NOT NULL,
  `precio_venta` decimal(10,2) NOT NULL,
  `precio_compra` decimal(10,2) NOT NULL DEFAULT 0.00,
  `existencias` int(11) NOT NULL DEFAULT 0,
  `stock_minimo` int(11) NOT NULL DEFAULT 0,
  `inventariable` tinyint(4) NOT NULL,
  `id_unidad` smallint(6) NOT NULL,
  `id_categoria` smallint(6) NOT NULL,
  `activo` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_codigo` (`codigo`),
  KEY `fk_producto_unidad` (`id_unidad`),
  KEY `fk_producto_categoria` (`id_categoria`),
  CONSTRAINT `fk_producto_categoria` FOREIGN KEY (`id_categoria`) REFERENCES `categorias` (`id`),
  CONSTRAINT `fk_producto_unidad` FOREIGN KEY (`id_unidad`) REFERENCES `unidades` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

TRUNCATE `productos`;
INSERT INTO `productos` (`id`, `codigo`, `nombre`, `precio_venta`, `precio_compra`, `existencias`, `stock_minimo`, `inventariable`, `id_unidad`, `id_categoria`, `activo`, `created_at`, `updated_at`) VALUES
(1,	'caca',	'prueba',	123.00,	456.00,	0,	1,	1,	1,	1,	1,	'2021-03-08 00:44:21',	'2021-03-08 00:44:21'),
(2,	'caca123',	'test',	1234.00,	5678.00,	2,	3,	0,	3,	2,	1,	'2021-03-11 00:22:23',	'2021-03-10 22:22:23');

DROP TABLE IF EXISTS `unidades`;
CREATE TABLE `unidades` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `nombre_corto` varchar(10) NOT NULL,
  `activo` tinyint(3) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

TRUNCATE `unidades`;
INSERT INTO `unidades` (`id`, `nombre`, `nombre_corto`, `activo`, `created_at`, `updated_at`) VALUES
(1,	'Kilogramo',	'Kg',	1,	'2021-03-07 19:16:58',	'2021-03-07 17:16:58'),
(2,	'Kilometro',	'Km',	1,	'2021-03-07 19:16:46',	'2021-03-07 17:16:46'),
(3,	'Gramo',	'grs1234567',	1,	'2021-03-10 16:04:25',	'2021-03-10 14:04:25');

-- 2021-03-11 23:33:33
