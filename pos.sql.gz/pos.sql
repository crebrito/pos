-- Adminer 4.8.0 MySQL 5.5.5-10.3.27-MariaDB-0+deb10u1 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP DATABASE IF EXISTS `pos`;
CREATE DATABASE `pos` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `pos`;

DROP TABLE IF EXISTS `cajas`;
CREATE TABLE `cajas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero_caja` varchar(10) NOT NULL,
  `nombre` varchar(35) NOT NULL,
  `folio` int(11) NOT NULL,
  `activo` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

TRUNCATE `cajas`;
INSERT INTO `cajas` (`id`, `numero_caja`, `nombre`, `folio`, `activo`, `created_at`, `updated_at`) VALUES
(1,	'A1',	'Principal',	123,	1,	'2021-03-12 01:57:34',	NULL),
(2,	'A2',	'Secundaria',	124,	1,	'2021-03-12 01:57:34',	NULL),
(3,	'A3',	'Caja 3',	124,	1,	'2021-03-12 12:25:14',	'2021-03-12 10:25:14');

DROP TABLE IF EXISTS `categorias`;
CREATE TABLE `categorias` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `activo` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

TRUNCATE `categorias`;
INSERT INTO `categorias` (`id`, `nombre`, `activo`, `created_at`, `updated_at`) VALUES
(1,	'Tecnologías',	1,	'2021-03-07 19:29:49',	'2021-03-07 17:29:49'),
(2,	'Papelería',	1,	'2021-03-10 16:46:50',	'2021-03-10 14:46:50');

DROP TABLE IF EXISTS `clientes`;
CREATE TABLE `clientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `direccion` varchar(150) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `correo` varchar(50) DEFAULT NULL,
  `activo` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

TRUNCATE `clientes`;
INSERT INTO `clientes` (`id`, `nombre`, `direccion`, `telefono`, `correo`, `activo`, `created_at`, `updated_at`) VALUES
(1,	'Carlos',	'alla',	'123456',	'aa@aa.com',	1,	'2021-03-11 01:05:01',	'2021-03-10 23:05:01');

DROP TABLE IF EXISTS `compras`;
CREATE TABLE `compras` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `folio` varchar(15) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `activo` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `fk_compras_usuario` (`id_usuario`),
  CONSTRAINT `fk_compras_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

TRUNCATE `compras`;
INSERT INTO `compras` (`id`, `folio`, `total`, `id_usuario`, `activo`, `created_at`, `updated_at`) VALUES
(1,	'604c3e7d9a2a9',	90.00,	1,	1,	'2021-03-13 02:24:50',	'2021-03-13 02:24:50'),
(2,	'604c3f6a75723',	45.00,	1,	1,	'2021-03-13 02:28:34',	'2021-03-13 02:28:34'),
(3,	'604c402d5d69e',	5.00,	1,	1,	'2021-03-13 02:32:29',	'2021-03-13 02:32:29'),
(4,	'604c4110f39dc',	456.00,	1,	1,	'2021-03-13 02:35:35',	'2021-03-13 02:35:35');

DROP TABLE IF EXISTS `configuracion`;
CREATE TABLE `configuracion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `valor` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

TRUNCATE `configuracion`;
INSERT INTO `configuracion` (`id`, `nombre`, `valor`) VALUES
(1,	'tienda_nombre',	'Tienda CDP'),
(2,	'tienda_rif',	'J-12345678-3'),
(3,	'tienda_correo',	'aa@aa.com'),
(4,	'tienda_telefono',	'04143404376'),
(5,	'tienda_direccion',	'Av. Mañongo 3'),
(6,	'ticket_leyenda',	'Gracias por su paciencia');

DROP TABLE IF EXISTS `detalle_compra`;
CREATE TABLE `detalle_compra` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_compra` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `nombre` varchar(200) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `fk_detalle_compra` (`id_compra`),
  KEY `fk_detalle_producto` (`id_producto`),
  CONSTRAINT `fk_detalle_compra` FOREIGN KEY (`id_compra`) REFERENCES `compras` (`id`),
  CONSTRAINT `fk_detalle_producto` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

TRUNCATE `detalle_compra`;
INSERT INTO `detalle_compra` (`id`, `id_compra`, `id_producto`, `nombre`, `cantidad`, `precio`, `created_at`, `updated_at`) VALUES
(1,	1,	1,	'prueba',	12,	456.00,	'2021-03-13 02:24:50',	'2021-03-13 02:24:50'),
(2,	1,	2,	'test',	15,	5678.00,	'2021-03-13 02:24:50',	'2021-03-13 02:24:50'),
(3,	2,	1,	'prueba',	100,	456.00,	'2021-03-13 02:28:34',	'2021-03-13 02:28:34'),
(4,	3,	2,	'test',	1,	5678.00,	'2021-03-13 02:32:29',	'2021-03-13 02:32:29'),
(5,	4,	1,	'prueba',	1,	456.00,	'2021-03-13 02:35:35',	'2021-03-13 02:35:35');

DROP TABLE IF EXISTS `productos`;
CREATE TABLE `productos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(20) NOT NULL,
  `nombre` varchar(200) NOT NULL,
  `precio_venta` decimal(10,2) NOT NULL,
  `precio_compra` decimal(10,2) NOT NULL DEFAULT 0.00,
  `existencias` int(11) NOT NULL DEFAULT 0,
  `stock_minimo` int(11) NOT NULL DEFAULT 0,
  `inventariable` tinyint(4) NOT NULL,
  `id_unidad` smallint(6) NOT NULL,
  `id_categoria` smallint(6) NOT NULL,
  `activo` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_codigo` (`codigo`),
  KEY `fk_producto_unidad` (`id_unidad`),
  KEY `fk_producto_categoria` (`id_categoria`),
  CONSTRAINT `fk_producto_categoria` FOREIGN KEY (`id_categoria`) REFERENCES `categorias` (`id`),
  CONSTRAINT `fk_producto_unidad` FOREIGN KEY (`id_unidad`) REFERENCES `unidades` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

TRUNCATE `productos`;
INSERT INTO `productos` (`id`, `codigo`, `nombre`, `precio_venta`, `precio_compra`, `existencias`, `stock_minimo`, `inventariable`, `id_unidad`, `id_categoria`, `activo`, `created_at`, `updated_at`) VALUES
(1,	'caca',	'prueba',	123.00,	456.00,	101,	1,	1,	1,	1,	1,	'2021-03-13 04:35:35',	'2021-03-13 02:35:35'),
(2,	'caca123',	'test',	1234.00,	5678.00,	1,	3,	0,	3,	2,	1,	'2021-03-13 04:32:29',	'2021-03-13 02:32:29');

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `activo` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

TRUNCATE `roles`;
INSERT INTO `roles` (`id`, `nombre`, `activo`, `created_at`, `updated_at`) VALUES
(1,	'Admin',	1,	'2021-03-12 01:56:29',	NULL),
(2,	'Cajero',	1,	'2021-03-12 01:56:29',	NULL),
(3,	'TestX',	1,	'2021-03-12 12:12:19',	'2021-03-12 10:12:19');

DROP TABLE IF EXISTS `temporal_compra`;
CREATE TABLE `temporal_compra` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `folio` varchar(15) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `codigo` varchar(20) NOT NULL,
  `nombre` varchar(200) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

TRUNCATE `temporal_compra`;

DROP TABLE IF EXISTS `unidades`;
CREATE TABLE `unidades` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `nombre_corto` varchar(10) NOT NULL,
  `activo` tinyint(3) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

TRUNCATE `unidades`;
INSERT INTO `unidades` (`id`, `nombre`, `nombre_corto`, `activo`, `created_at`, `updated_at`) VALUES
(1,	'Kilogramo',	'Kg',	1,	'2021-03-07 19:16:58',	'2021-03-07 17:16:58'),
(2,	'Kilometro',	'Km',	1,	'2021-03-07 19:16:46',	'2021-03-07 17:16:46'),
(3,	'Gramo',	'grs1234567',	1,	'2021-03-10 16:04:25',	'2021-03-10 14:04:25');

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(30) NOT NULL,
  `password` varchar(130) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `id_caja` int(11) NOT NULL,
  `id_rol` int(11) NOT NULL,
  `activo` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_caja` (`id_caja`),
  KEY `id_rol` (`id_rol`),
  CONSTRAINT `fk_usuario_caja` FOREIGN KEY (`id_caja`) REFERENCES `cajas` (`id`),
  CONSTRAINT `fk_usuario_rol` FOREIGN KEY (`id_rol`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

TRUNCATE `usuarios`;
INSERT INTO `usuarios` (`id`, `usuario`, `password`, `nombre`, `id_caja`, `id_rol`, `activo`, `created_at`, `updated_at`) VALUES
(1,	'crebrito',	'$2y$10$qhHfdnN99azyT0FGCqsK.uBrK3ek5HblNNWpC9cF98prO/.2ubyGu',	'Carlos',	1,	1,	1,	'2021-03-12 12:00:43',	'2021-03-12 10:00:43'),
(2,	'crebrito2',	'$2y$10$YXnWp7R9s2iVFXkVkQLgB.e.7LaLQnOJjG3evomGk5Xfbdw1wSZ46',	'Carlos 2',	2,	2,	1,	'2021-03-12 00:08:17',	'2021-03-12 00:08:17');

-- 2021-03-13 04:38:53
